<?php
include "include/koneksi.php";

$No_Order = $_POST["No_Order"];
$No_Identitas = $_POST["No_Identitas"];
$total_berat = $_POST["total_berat"];
$diskon = $_POST["diskon"];
$total_bayar = $_POST["total_bayar"];
$Tgl_Terima = $_POST["tanggal"];

// Validate required fields
if(empty($No_Order) || empty($No_Identitas) || empty($total_berat) || empty($total_bayar) || empty($Tgl_Terima)) {
    echo "<script language='javascript'>alert('Gagal di tambahkan: Semua field wajib diisi!');</script>";
    echo '<meta http-equiv="refresh" content="0; url=editdatatransaksi.php?edit=' . $No_Order . '">';
    exit();
}

$sql = "CALL Update_Transaksi('$No_Order', '$No_Identitas', $total_berat, $diskon, $total_bayar)";

try {
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script language='javascript'>alert('Berhasil di Edit');</script>";
        echo '<meta http-equiv="refresh" content="0; url=transaksi.php">';
    } else {
        throw new Exception('Gagal di edit: ' . $conn->error);
    }
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1644) { // 1644 is the code for a custom signal
        echo "<script language='javascript'>alert('Gagal di edit: Total berat tidak boleh kurang dari 0!');</script>";
    } else {
        echo "<script language='javascript'>alert('Gagal di edit: " . $e->getMessage() . "');</script>";
    }
    echo '<meta http-equiv="refresh" content="0; url=editdatatransaksi.php?edit=' . $No_Order . '">';
}
?>
