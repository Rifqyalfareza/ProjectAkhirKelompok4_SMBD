<?php
include "include/koneksi.php";

$No_Order = $_GET['hapus'];

if (empty($No_Order)) {
    echo "<script language='javascript'>alert('No Order tidak ditemukan');</script>";
    echo '<meta http-equiv="refresh" content="0; url=transaksi.php">';
    exit();
}

try {
    $sql = "CALL Delete_Transaksi('$No_Order')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script language='javascript'>alert('Berhasil dihapus');</script>";
        echo '<meta http-equiv="refresh" content="0; url=transaksi.php">';
    } else {
        throw new Exception('Gagal dihapus');
    }
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1644) { 
        echo "<script language='javascript'>alert('Tidak dapat menghapus transaksi jika belom diambil');</script>";
    } else {
        echo "<script language='javascript'>alert('Gagal dihapus');</script>";
    }
    echo '<meta http-equiv="refresh" content="0; url=transaksi.php">';
}
?>
