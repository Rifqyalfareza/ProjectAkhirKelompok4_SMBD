<?php
include "include/koneksi.php";

$No_Order = $_POST["No_Order"];
$No_Identitas = $_POST["No_Identitas"];
$total_berat = $_POST["total_berat"];
$diskon = $_POST["diskon"];
$total_bayar = $_POST["total_bayar"];
$Tgl_Terima = $_POST["tanggal"];

if(empty($No_Order) || empty($No_Identitas) || empty($total_berat) || empty($total_bayar) || empty($Tgl_Terima)){
	echo "<script language='javascript'>alert('Gagal di tambahkan: Semua field harus diisi');</script>";
	echo '<meta http-equiv="refresh" content="0; url=tambahdatatransaksi.php">';
} else {
	try {
		// Coba menjalankan query
		$sql = "CALL Insert_Transaksi('$No_Order', '$No_Identitas', '$Tgl_Terima', $total_berat, $diskon, $total_bayar)";
		if ($conn->query($sql) === TRUE) {
			echo "<script language='javascript'>alert('Berhasil di tambahkan');</script>";
			echo '<meta http-equiv="refresh" content="0; url=transaksi.php">';
		} else {
			// Jika terjadi kesalahan, cek apakah kesalahannya adalah total berat yang kurang dari 0
			if ($conn->errno == 1644) {
				echo "<script language='javascript'>alert('Gagal di tambahkan: Total berat tidak boleh kurang dari 0');</script>";
			} else {
				echo "<script language='javascript'>alert('Gagal di tambahkan: " . $conn->error . "');</script>";
			}
			echo '<meta http-equiv="refresh" content="0; url=tambahdatatransaksi.php">';
		}
	} catch (mysqli_sql_exception $e) {
		// Tangkap kesalahan dan tampilkan pesan
		echo "<script language='javascript'>alert('Gagal di tambahkan: " . $e->getMessage() . "');</script>";
		echo '<meta http-equiv="refresh" content="0; url=tambahdatatransaksi.php">';
	}
}

$conn->close();
?>
