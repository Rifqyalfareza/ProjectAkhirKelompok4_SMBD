<?php
include "include/koneksi.php";

$No_Identitas = $_POST["No_Identitas"];
$Nama = $_POST["Nama"];
$Alamat = $_POST["Alamat"];
$No_Hp = $_POST["No_Hp"];

if(empty($No_Identitas) || empty($Nama) || empty($Alamat) || empty($No_Hp)){
    echo "<script language='javascript'>alert('Gagal ditambahkan: Semua field harus diisi');</script>";
    echo '<meta http-equiv="refresh" content="0; url=tambahdatapelanggan.php">';
} else {
        
    // Validasi nomor telepon harus 12 angka di sisi PHP sebelum melakukan query ke database
    // if (strlen($No_Hp) != 12) {
    //     echo "<script language='javascript'>alert('Gagal ditambahkan: Nomor HP harus 12 angka');</script>";
    //     echo '<meta http-equiv="refresh" content="0; url=tambahdatapelanggan.php">';
    //     exit();
    // }

    // Try to execute the stored procedure and catch any exceptions
    try {
        $sql = "CALL Insert_Pelanggan('$No_Identitas', '$Nama', '$Alamat', '$No_Hp')";
        if (mysqli_query($conn, $sql)) {
            echo "<script language='javascript'>alert('Berhasil ditambahkan');</script>";
            echo '<meta http-equiv="refresh" content="0; url=pelanggan.php">';
        } else {
            // Handle any query errors
            throw new Exception(mysqli_error($conn));
        }
    } catch (mysqli_sql_exception $e) {
        // Check for the specific error message from the trigger
        if (strpos($e->getMessage(), 'No_Identitas sudah ada') !== false) {
            echo "<script language='javascript'>alert('Gagal ditambahkan: No_Identitas sudah ada');</script>";
        } else {
            echo "<script language='javascript'>alert('Gagal ditambahkan: " . $e->getMessage() . "');</script>";
        }
        echo '<meta http-equiv="refresh" content="0; url=tambahdatapelanggan.php">';
    } 
}
mysqli_close($conn);
?>
