<?php
session_start();
if(isset($_SESSION['id'])){
    include "include/koneksi.php";

    function fetchData($conn, $procedure) {
        $query = "CALL $procedure";
        $data = [];

        if (mysqli_multi_query($conn, $query)) {
            do {
                if ($result = mysqli_store_result($conn)) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $data[] = $row;
                    }
                    mysqli_free_result($result);
                }
            } while (mysqli_next_result($conn));
        }
        
        return $data;
    }

    $queryTotalBayar = "SELECT * FROM view_total_bayar_keseluruhan";
    $resultTotalBayar = mysqli_query($conn, $queryTotalBayar);
    $rowTotalBayar = mysqli_fetch_assoc($resultTotalBayar);
    $totalBayar = $rowTotalBayar['total_bayar_keseluruhan'];

    $queryTotalTransaksi = "SELECT * FROM view_total_transaksi";
    $resultTotalTransaksi = mysqli_query($conn, $queryTotalTransaksi);
    $rowTotalTransaksi = mysqli_fetch_assoc($resultTotalTransaksi);
    $totalTransaksi = $rowTotalTransaksi['total_transaksi'];

    $queryJumlahPakaianBelumDiambil = "SELECT * FROM view_jumlah_pakaian_belum_diambil";
    $resultJumlahPakaianBelumDiambil = mysqli_query($conn, $queryJumlahPakaianBelumDiambil);
    $rowJumlahPakaianBelumDiambil = mysqli_fetch_assoc($resultJumlahPakaianBelumDiambil);
    $jumlahPakaianBelumDiambil = $rowJumlahPakaianBelumDiambil['jumlah_pakaian_belum_diambil'];

    $queryJumlahPakaianSudahDiambil = "SELECT * FROM view_jumlah_pakaian_sudah_diambil";
    $resultJumlahPakaianSudahDiambil = mysqli_query($conn, $queryJumlahPakaianSudahDiambil);
    $rowJumlahPakaianSudahDiambil = mysqli_fetch_assoc($resultJumlahPakaianSudahDiambil);
    $jumlahPakaianSudahDiambil = $rowJumlahPakaianSudahDiambil['jumlah_pakaian_sudah_diambil'];

    // Ambil data pakaian yang sudah diambil menggunakan prosedur GetPakaianDiambil
    $pakaianDiambil = fetchData($conn, 'GetPakaianDiambil');

    // Ambil data pakaian yang belum diambil menggunakan prosedur GetPakaianBelumDiambil
    $pakaianBelumDiambil = fetchData($conn, 'GetPakaianBelumDiambil');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <?php include "include/header.php"; ?>
    <style>
        body {
            background-color: #f5f5f5;
            font-family: 'Roboto', sans-serif;
        }
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
            width: 100%;
            border-radius: 10px;
            margin: 10px 0;
            padding: 20px;
            text-align: center;
            background-color: #fff;
        }
        .card h3 {
            margin: 0;
            font-size: 1.5em;
            color: #333;
        }
        .card p {
            margin: 10px 0 0;
            font-size: 1.2em;
            color: #666;
        }
        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        }
        .card.total-bayar {
            border-left: 5px solid #28a745;
        }
        .card.total-transaksi {
            border-left: 5px solid #007bff;
        }
        .card.belum-diambil {
            border-left: 5px solid #ffc107;
            cursor: pointer;
        }
        .card.sudah-diambil {
            border-left: 5px solid #dc3545;
            cursor: pointer;
        }
        .navbar-brand {
            font-size: 1.8em;
            font-weight: bold;
        }
        .jumbotron {
            background: linear-gradient(to bottom, #007bff, #0056b3);
            color: white;
            padding: 100px 25px;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 10px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        #pakaianDiambilContent p, #pakaianBelumDiambilContent p {
            text-align: left;
            font-size: 1em;
            color: #333;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Laundry</a>
            </div>
            <ul class="nav navbar-nav">
                <?php include "include/list.php"; ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="card total-bayar">
                    <h3>Pendapatan</h3>
                    <p><?php echo "Rp " . number_format($totalBayar, 0, ",", "."); ?></p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card total-transaksi">
                    <h3>Transaksi</h3>
                    <p><?php echo $totalTransaksi; ?></p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card belum-diambil" id="belum-diambil">
                    <h3>Pakaian Belum Diambil</h3>
                    <p><?php echo $jumlahPakaianBelumDiambil; ?></p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card sudah-diambil" id="sudah-diambil">
                    <h3>Pakaian Diambil</h3>
                    <p><?php echo $jumlahPakaianSudahDiambil; ?></p>
                </div>
            </div>
        </div>

        <div id="pakaianDiambilModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Detail Pakaian Diambil</h2>
                <div id="pakaianDiambilContent">
                    <?php
                    if (!empty($pakaianDiambil)) {
                        foreach ($pakaianDiambil as $item) {
                            echo "<p>No: {$item['No_Order']} - Jenis: {$item['Jenis_Pakaian']} - Jumlah: {$item['Jumlah_Pakaian']}</p>";
                        }
                    } else {
                        echo "<p>Tidak ada data pakaian diambil.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <div id="pakaianBelumDiambilModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Detail Pakaian Belum Diambil</h2>
                <div id="pakaianBelumDiambilContent">
                    <?php
                    if (!empty($pakaianBelumDiambil)) {
                        foreach ($pakaianBelumDiambil as $item) {
                            echo "<p>No: {$item['No_Order']} - Jenis: {$item['Jenis_Pakaian']} - Jumlah: {$item['Jumlah_Pakaian']}</p>";
                        }
                    } else {
                        echo "<p>Tidak ada data pakaian belum diambil.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="jumbotron text-center">
            <h1>SELAMAT DATANG ADMIN</h1>
        </div>
    </div>

    <script>
        var modalDiambil = document.getElementById("pakaianDiambilModal");
        var btnDiambil = document.getElementById("sudah-diambil");
        var modalBelumDiambil = document.getElementById("pakaianBelumDiambilModal");
        var btnBelumDiambil = document.getElementById("belum-diambil");
        var span = document.getElementsByClassName("close");

        btnDiambil.onclick = function() {
            modalDiambil.style.display = "block";
        }

        btnBelumDiambil.onclick = function() {
            modalBelumDiambil.style.display = "block";
        }

        for (let i = 0; i < span.length; i++) {
            span[i].onclick = function() {
                modalDiambil.style.display = "none";
                modalBelumDiambil.style.display = "none";
            }
        }

        window.onclick = function(event) {
            if (event.target == modalDiambil) {
                modalDiambil.style.display = "none";
            }
            if (event.target == modalBelumDiambil) {
                modalBelumDiambil.style.display = "none";
            }
        }
    </script>
</body>
</html>

<?php
}else{
    header("location:login/index.php");
}
?>
