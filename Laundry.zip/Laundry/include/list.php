<li><a href="index1.php">Beranda</a></li>
<li><a href="tambahdatatransaksi.php">Transaksi Laundry</a></li>
<li><a href="transaksi.php">Data Transaksi</a></li>
<li><a href="pakaian.php">Data Pakaian</a></li>
<li><a href="pelanggan.php">Data Pelanggan</a></li>

